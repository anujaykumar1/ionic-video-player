require('./vg-poster');

module.exports = 'com.2fdevs.videogular.plugins.poster';
