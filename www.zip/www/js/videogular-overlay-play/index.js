require('./vg-overlay-play');

module.exports = 'com.2fdevs.videogular.plugins.overlayplay';
