require('./vg-ima-ads');

module.exports = 'com.2fdevs.videogular.plugins.imaads';
