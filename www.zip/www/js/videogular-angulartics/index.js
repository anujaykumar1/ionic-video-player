require('angulartics');
require('./vg-analytics');

module.exports = 'com.2fdevs.videogular.plugins.analytics';
