require('./videogular');

module.exports = 'com.2fdevs.videogular';
