require('./vg-buffering');

module.exports = 'com.2fdevs.videogular.plugins.buffering';
