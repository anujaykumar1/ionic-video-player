require('./vg-controls');

module.exports = 'com.2fdevs.videogular.plugins.controls';
